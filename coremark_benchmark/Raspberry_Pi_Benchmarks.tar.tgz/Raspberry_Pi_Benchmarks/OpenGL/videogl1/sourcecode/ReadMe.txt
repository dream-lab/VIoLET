Compile using terminal command

gcc ogl1.c cpuidc.c -lrt  -lm -O3 -lglut -lGLU -lGL -o videogl32

Before running, ensure that the compiled benchmark is in the same folder as the .bmp image files.